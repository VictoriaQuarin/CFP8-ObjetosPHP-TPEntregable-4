function calcular(){
    //alert("Se ejecuto la función!")
    nro1=parseFloat(document.getElementById("nro1").value)
    nro2=parseFloat(document.getElementById("nro2").value)
    operacion=document.getElementById("operacion").value
    //console.log(nro1)
    //console.log(nro2)
    //console.log(operacion)
    //operacion 'suma' 'resta' 'div' 'multi'
    resultado="0"
    switch(operacion){
        case "suma":        resultado=nro1+nro2;        break;
        case "resta":       resultado=nro1-nro2;        break;
        case "multi":       resultado=nro1*nro2;        break;
        case "div":
                if(nro2!=0){
                    resultado=nro1+nro2;
                }else{
                    resultado="Error / 0"
                }
            break;
    }
    document.getElementById("resultado").innerText=resultado
}