// Resolución - Versión 1

function calculo_IMC(){

    peso=parseFloat(document.getElementById("peso").value)
    altura=parseFloat(document.getElementById("altura").value) / 100;
    imc = peso / (altura * altura);

    calculo_Resultado(imc);         //Determina uno de los rangos listados en calculo_Resultado; de acuerdo al valor del IMC calculado.
    document.getElementById("calculo_IMC").innerText=imc
}


function calculo_Resultado(imc){

    resultado = ""

    if (imc <= 15){
        resultado = "Cuadro de Delgadez muy Severa";
    
    } else if (imc >= 15 && imc <= 15.9){
        resultado = "Cuadro de Delgadez Severa";

    } else if (imc >= 16 && imc <= 18.4){
        resultado = "Cuadro de Delgadez";

    } else if (imc >= 18.5 && imc <= 24.9){
        resultado = "Valor Normal";

    } else if (imc >= 25 && imc <= 29.9){
        resultado = "Cuadro de Sobrepeso";

    } else if (imc >= 30 && imc <= 34.9){
        resultado = "Cuadro de Obesidad Moderada";

    } else if (imc >= 35 && imc <= 39.9){
        resultado = "Cuadro de Obesidad Severa";

    } else {
        resultado = "Cuadro de Obesidad Mórbida";
    }


    document.getElementById("calculo_Resultado").innerText=resultado
}


// Resolución - Versión 2
/*

function calculo_IMC() {
    peso=parseFloat(document.getElementById("peso").value)
    altura=parseFloat(document.getElementById("altura").value) / 100;
    imc = peso / (altura * altura);

    calculo_Resultado(imc);
    document.getElementById("calculo_IMC").innerText=imc
}


function calculo_Resultado(imc){
    resultado = ""

    switch(true){

        case (imc <= 15):
            resultado = "Cuadro de Delgadez Muy Severa";
            break;

        case (imc >= 15 && imc <= 15.9):
            resultado = "Cuadro de Delgadez Severa";
            break;

        case (imc >= 16 && imc <= 18.4):
            resultado = "Cuadro de Delgadez";
            break;

        case (imc >= 18.5 && imc <= 24.9):
            resultado = "Valor Normal";
            break;

        case (imc >= 25 && imc <= 29.9):
            resultado = "Cuadro de Sobrepeso";
            break;

        case (imc >= 30 && imc <= 34.9):
            resultado = "Cuadro de Obesidad Moderada";
            break;

        case (imc >= 35 && imc <= 39.9):
            resultado = "Cuadro de Obesidad Severa";
            break;

        case (imc >= 40):
            resultado = "Cuadro de Obesidad Mórbida";
            break;
    
    }

    document.getElementById("calculo_Resultado").innerText=resultado

}
*/