function calculo_IMC(){

    peso=parseFloat(document.getElementById("peso").value)
    altura=parseFloat(document.getElementById("altura").value)
    calculoIMC=document.getElementById("calculo_IMC").value


    function calculo_Resultado(calculoIMC) {
        if ($imc <= 15){
            return "Cuadro de Delgadez muy Severa";
    
        } else if ($imc >= 15 && $imc <= 15.9){
            return "Cuadro de Delgadez Severa";
    
        } else if ($imc >= 16 && $imc <= 18.4){
            return "Cuadro de Delgadez";
    
        } else if ($imc >= 18.5 && $imc <= 24.9){
            return "Valor Normal";
    
        } else if ($imc >= 25 && $imc <= 29.9){
            return "Cuadro de Sobrepeso";
    
        } else if ($imc >= 30 && $imc <= 34.9){
            return "Cuadro de Obesidad Moderada";
    
        } else if ($imc >= 35 && $imc <= 39.9){
            return "Cuadro de Obsesidad Severa";
    
        } else {
            return "Cuadro de Obesidad Mórbida";
        }
    }

// ÉSTE TRABAJO DEBE HACERSE CON, TP4, DEBE HACERSE CON:  HTML JS CSS-Bootstrap
    document.getElementById("calculo_IMC").innerText=calculoIMC






}