<?php
    //echo 'Hola Mundo';
    $user=$_POST['user'];
    $pass=$_POST['pass'];
    //echo $user.' '.$pass;
    if(isset($_GET['user']) || isset($_GET['root'])){
        echo 'No se permiten parámetros por GET';
    }else{
        if($user=='root' && $pass=='1234'){
            echo 'Bienvenido al sistema!';
        }else{
            echo 'Credenciales incorrectas!';
        }
    }

?>