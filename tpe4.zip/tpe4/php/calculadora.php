<?php
//echo "Hola Mundo!";
$nro1 = $_REQUEST['nro1'];
$nro2 = $_REQUEST['nro2'];
$operacion = $_REQUEST['operacion'];

//echo $nro1.', '.$nro2.', '.$operacion;

switch ($operacion) {
    case 'suma':
        echo ($nro1 + $nro2);
        break;
    case 'resta':
        echo ($nro1 - $nro2);
        break;
    case 'multi':
        echo ($nro1 * $nro2);
        break;
    case 'div':
        if ($nro2 != 0) {
            echo ($nro1 / $nro2);
        } else {
            echo 'Error Div /0 !';
        }
        break;
}
?>