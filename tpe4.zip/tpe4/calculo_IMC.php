<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UFT-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>TPE 4 - Cálculo del IMC</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
</head>
<body>

    <!-- http://localhost/objetos/tpe4/calculo_IMC.php -->

    <div class="container-lg bg-subtle">
        <h1 class="bg-success-subtle text-center p-2 m-2">Trabajo Práctico Entregable 4</h1>
        <h2 class="bg-danger-subtle text-center p-2 m-2">Cálculo del Índice de Masa Corporal</h2>

    <form class="bg-secondary-subtle m3 p-3">


        <!-- Peso -->
        <div class="mb-3 row">
            <label for="peso" class="col-sm-3 col-form-label bs-success-subtle"> Peso (en kg.) </label>
            <div class="col-sm-3">
                <input type="number" name="peso" class="form-control text-primary" id="peso" minlength="1" maxlength="5"
                    required placeholder="Ingresar su peso en kilos">
            </div>
        </div>


        <!-- Altura -->
        <div class="mb-3 row">
            <label for="altura" class="col-sm-3 col-form-label bs-success-subtle"> Altura (en cm.) </label>
            <div class="col-sm-3">
                <input type="number" name="altura" class="form-control text-primary" id="altura" minlength="1" maxlength="5"
                    required placeholder="Ingresar su altura en centímetros">
            </div>
        </div>


        <!-- IMC -->
        <div class="mb-3 row">
            <label for="imc" class="col-sm-3 col-form-label bs-success-subtle"> IMC </label>
            <div class="col-sm-3">
                <div class="form-control bs-success-subtle" id="calculo_IMC">
                </div>
            </div>
        </div>


        <!-- Resultado -->
        <div class="mb-3 row">
            <label for="resultado" class="col-sm-3 col-form-label bs-success-subtle"> Resultado </label>
            <div class="col-sm-3">
                <div class="form-control bs-success-subtle" id="calculo_Resultado">
                </div>
            </div>
        </div>
               
        
        <!-- Botones -->
        <div class="mb-1 row">
            <div class="col-sm-3">
                <input type="button" onclick="calculo_IMC()" class="btn btn-success btn-sm" value="Calcular">
                <input type="reset" class="btn btn-danger btn-sm" value="Borrar">
            </div>
        </div>


    </form>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz"
        crossorigin="anonymous"></script>

    <script src="js/calculo_IMC.js"></script>

</body>
</html>