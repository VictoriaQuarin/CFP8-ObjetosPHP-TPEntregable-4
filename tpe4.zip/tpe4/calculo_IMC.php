<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>TPE 3 - Cálculo del IMC</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">

</head>
<body>
    <!-- http://localhost/objetos/tpe4/calculo_IMC.php -->

    <div class="container-lg bg-subtle">
        <h1 class="bg-info-subtle text-center p-2 m-2">Trabajo Práctico Entregable 3</h1>
        <h2 class="bg-success-subtle text-center p-2 m-2">Cálculo del Índice de Masa Corporal</h2>

    <form class="bg-secondary-subtle m3 p-3" method="POST">

        <!-- Peso -->
        <div class="mb-3 row">
            <label for="peso" class="col-sm-3 col-form-label bs-success-subtle"> Peso (en kg.)</label>
            <div class="col-sm-3">
                <input type="number" name="peso" class="form-control text-primary" id="peso" minlenght="1" maxlenght="5"
                    required placeholder="Ingresar su peso en kilos">
            </div>
        </div>


        <!-- Altura -->
        <div class="mb-3 row">
            <label for="altura" class="col-sm-3 col-form-label bs-success-subtle"> Altura (en cm.)</label>
            <div class="col-sm-3">
                <input type="number" name="altura" class="form-control text-primary" id="altura" minlenght="1" maxlenght="5"
                required placeholder="Ingresar su altura en centímetros">
            </div>
        </div>

        
        <!-- Resultado -->
        <div class="mb-3 row">
            <label for="resultado" class="col-sm-3 col-form-label bs-success-subtle"> Resultado</label>
            <div class="col-sm-5">
                <div class="form-control bs-success-subtle" id="resultado">
                    <?php include 'php/calculo_IMC.php';?>
                </div>
            </div>
        </div>


        <!-- Botones -->
        <div class="mb-3 row">
            <button type="submit" class="btn btn-outline-primary btn-sm col-sm-3 m-2">Calcular</button>
            <button type="reset" class="btn btn-outline-danger btn-sm col-sm-3 m-2">Borrar</button>
        </div>


        <input type="button" onclick="calculo_IMC()" class="boton botonEnviar" value="Calcular">
        <div input type="reset" class="botton botonBorrar" value="Borrar"></div>

        <td><input type="button" onclick="calcular()" class="boton botonEnviar" value="Calcular"></td>

    </form>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz"
        crossorigin="anonymous"></script>



<!--SACARME LA DUDA DE LAS RELACIONES ENTRE JSS BOOTSTRAP PHP HTML, Y CÓMO FUNCIONA LA INCRUSTACIÓN EN CADA CÓDIGO QUE ESTUVIMOS VIENDO-->
<!--DECLARAR CLAVE FORÁNEA-->
<!--EL "DER" DEBE ESTAR PROBADO PARA VER SI EXISTE LA CONEXIÓN-->
<!--CUAL ES LA DIFERENCIA ENTRE EL 127.0.0.1 Y EL 127.0.0.0-->
<!--ALGO RELACIONADO AL DHTC/HTTS o algo así y el código (ID/NAME, porque debo colocar NAME en el TP3 y no en el TP4, en el TP4 basta con ID)-->
<!--https://www.forosdelweb.com/f18/onclick-con-php-433944/-->
<!--https://www.forosdelweb.com/f13/como-sustituir-onclick-html-por-addeventlistener-1045612/-->
<!-- CONSULTAR/FIJARSE SI ES MEJOR ESCRIBIR LOS DOCUMENTOS calculo_IMC o calculoIMC-->
<!---->


</body>
</html>