<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Calculadora</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <!-- http://localhost/objetos/tpe4/calculadora.php --> 
    <h1>Calculadora</h1>
    <form>
        <table>
            <tr>
                <td><label class="etiqueta">Peso: </label></td>
                <td>
                    <input type="number" name="peso" id="peso" class="input texto" value="0" step="0.0001">
                </td>
            </tr>
            <tr>
                <td><label class="etiqueta">Altura: </label></td>
                <td>
                    <input type="number" name="altura" id="altura" class="input texto" value="0" step="0.0001">
                </td>
            </tr>
            <tr>
                <td><label class="etiqueta">Operación: </label></td>
                <td>
                    <select class="input select" name="operacion" id="operacion" >
                        <option value="suma" >Sumar</option>
                        <option value="resta">Restar</option>
                        <option value="div">Dividir</option>
                        <option value="multi">Multiplicar</option>
                    </select>
                </td>
            </tr>
            <tr>
                <td><input type="reset"  class="boton botonBorrar" value="Borrar"></td>
                <td><input type="button" onclick="calcular()" class="boton botonEnviar" value="Calcular"></td>
            </tr>
            <tr>
                <td><label class="etiqueta">Resultado: </label></td>
                <td>
                    <div class="input text" id="resultado">
                        0
                        <?
                            //php include_once "php/calculadora.php";
                        
                        ?>
                    </div>
                </td>
            </tr>
        </table>
    </form>
    <script src="js/calculadora.js"></script>
</body>
</html>